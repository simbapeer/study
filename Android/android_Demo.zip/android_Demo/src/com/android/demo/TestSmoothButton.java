package com.android.demo;

import android.app.Activity;
import android.os.Bundle;

public class TestSmoothButton extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.smooth_button_main);
	}
}
