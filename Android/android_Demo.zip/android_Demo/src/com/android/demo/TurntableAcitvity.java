package com.android.demo;

import com.android.demo.widget.Turntable;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class TurntableAcitvity extends Activity {
	  /** Called when the activity is first created. */  
    @Override  
    public void onCreate(Bundle savedInstanceState) {   
           
        super.onCreate(savedInstanceState);   
        setContentView(R.layout.turntable);   
        findViewAndButton();   
    }  
    
    private void findViewAndButton(){   
           
        //自定义的View   
        final Turntable panView=(Turntable) this.findViewById(R.id.zhuanpanView);   
           
        //开始旋转的按钮   
        Button startButton=(Button) this.findViewById(R.id.startButton);   
        startButton.setOnClickListener(new OnClickListener(){   
  
            public void onClick(View v) {   
                   
                panView.startRotate();   
                   
            }   
               
        });   
        //停止旋转的按钮   
        Button stopButton=(Button) this.findViewById(R.id.stopButton);   
        stopButton.setOnClickListener(new Button.OnClickListener(){   
  
            public void onClick(View v) {   
                   
                panView.stopRotate();   
                   
            }   
               
        });   
           
    }   

}
